function setup() {
  createCanvas(400, 400);
}
let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["🍉", "🍊", "🍋", "🍍"];
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length;

let jogoAtivo = false; 
let botao;

function setup() {
  createCanvas(400, 400);
  textSize(32);

  // cria o botão de "Jogar"
  botao = createButton("▶️ Jogar");
  botao.position(150, 180);
  botao.size(100, 40);
  botao.mousePressed(iniciarJogo);
}

function draw() {
  background("#D2EBB5");

  if (!jogoAtivo) {
    // mostra instruções enquanto não começou
    textSize(16);
    fill(0);
    textAlign(CENTER);
    text("Pressione:\nA para 🍉| S para 🍊\nD para🍋 | F para 🍍 e uma corrida de frutas", width / 2, 100);
    text("Clique em ▶️ Jogar para começar!", width / 2, 160);
  } else {
    // jogo rodando normalmente
    ativaJogo();
    desenhaJogadores();
    desenhaLinhaDeChegada();
    verificaVencedor();
  }
}

function iniciarJogo() {
  jogoAtivo = true;
  botao.hide(); // esconde o botão após clicar
}

function ativaJogo() {
  if (focused == true) {
    background("#D2EBB5");
  } else {
    background("rgb(38,108,178)");
  }
}

function desenhaJogadores() {
  for (let i = 0; i < quantidade; i++) {
    textSize(32);
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenhaLinhaDeChegada() {
  fill("green");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      text(jogador[i] + " venceu!", 50, 200);
      noLoop();
    }
  }
}

function keyReleased() {
  if (!jogoAtivo) return; // impede jogar antes do botão
  for (let i = 0; i < quantidade; i++) {
    if (key == teclas[i]) {
      xJogador[i] += random(20);
    }
  }
}